class bgClass {
	constructor() {
		this.status = 'inactive';
		this.cur_azs_id = 0;
		this.azs_cnt = 0;
		this.azs_ptr = 0;
		this.parse_tab_id = 0;
		bgClass.MAPS_URL = 'yandex.ru/maps/org/';
		bgClass.MAPS_ADDR = 'https://'+bgClass.MAPS_URL;
	}
	onUpdateTab(id, info, tab) {
		if (info && info.status) {
			switch (info.status) {
				case 'complete':
					if (this.isActive()
						&& (id == this.parse_tab_id)) {
						chrome.tabs.sendMessage(id,{method:'_parse',
										data:{azs_id:this.cur_azs_id,
												azs_ptr:this.azs_ptr,
												azs_cnt:this.azs_cnt}});
					}
				break;
			}
		}
	}
	getStatus() {
		return this.status;
	}
	isActive() {
		return this.getStatus()=='active'?true:false;
	}
	setStatus(status) {
		this.status = status;
		if (this.status == 'active')
			this.initTab(bgClass.MAPS_ADDR+this.cur_azs_id);
	}
	async initTab(url_addr) {
		if (!this.parse_tab_id) {
			let tab = await chrome.tabs.create({url:url_addr,active:false});
			this.parse_tab_id = tab.id;
		}
		else {
			try {
				await chrome.tabs.update(this.parse_tab_id, {url:url_addr, active:false});
			}
			catch (e) {
				let tab = await chrome.tabs.create({url:url_addr,active:false});
				this.parse_tab_id = tab.id;
			}
		}
	}
	async openAzsTab(data) {
//		console.log(data);
		if (this.isActive() && data) {
			if (data.cnt)
				this.azs_cnt = parseInt(data.cnt);
			if (data.azs_ptr)
				this.azs_ptr = parseInt(data.azs_ptr);
			if (data.azs_id && (this.cur_azs_id = parseInt(data.azs_id))) {
//				this.azs_ptr ++;
				await this.initTab(bgClass.MAPS_ADDR+this.cur_azs_id);
			}
			else {
				this.setStatus('inactive');
				this.parse_tab_id = 0;
				this.cur_azs_id = 0;
				this.azs_ptr = 0;
			}
		}
	}
}
let bg = new bgClass();

chrome.tabs.onUpdated.addListener((id, info, tab) => bg.onUpdateTab(id, info, tab));
chrome.runtime.onMessage.addListener((msg,sender,sendResp) => {
		if (typeof bg[msg.method] !== 'undefined') {
			if (typeof sendResp == 'undefined')
				bg[msg.method](typeof msg.data != 'undefined'?msg.data:null);
			else
				sendResp(bg[msg.method](typeof msg.data != 'undefined'?msg.data:null));
		}
	}
);
