class YMSurfer {
	constructor() {
		YMSurfer.SERVICE_URL = 'parser.azsgazprom.ru/'; // azsparser.webstab.ru/ parser.azsgazprom.ru/
		YMSurfer.SERVICE_ADDR = 'https://'+YMSurfer.SERVICE_URL;

		this.send_data = true;

		this.xhr = YMSurfer.getXhrObject();
		this.xhr.responseType = 'json';
		this.xhr.addEventListener('load', () => this.xhrResponse());
	}
	static getXhrObject() {
		if(typeof XMLHttpRequest === 'undefined'){
			XMLHttpRequest = function() {
				try {
					return new window.ActiveXObject("Microsoft.XMLHTTP");
				}
				catch(err) {
					alert('YMSurfer.getXhrObject error: Can not create XMLHttp object');
				}
			}
		}
		return new XMLHttpRequest();
	}
	xhrResponse() {
		try {
			if (this.xhr.readyState == 4) {
				if (this.xhr.status == 200) {
					let resp;
					if (resp = this.xhr.response) {
						if (resp && resp.error) {
							alert(resp.error);
						}
						else if (this.send_data) {
							this.sendData(resp);
						}
						
					}
				}
				else
					alert('Ошибка ответа сервера: '+this.xhr.status);
			}
		}
		catch (err) {
			alert('Сетевая ошибка при получении ответа на запрос: '+err.message);
		}
	}
	_parse(data) {
		let elems;
		let out = {};
		let azs_id = parseInt(data.azs_id);
		let _obj = this;
		
		let wndinfo = document.createElement('div');
		if (azs_id)
			wndinfo.innerHTML = '<div id="parse-progress">Обработано '+data.azs_ptr+' АЗС из '+data.azs_cnt+' ...<div>ID: '+azs_id+'</div></div>';
		else
			wndinfo.innerHTML = '<div id="parse-progress">Инициализация парсинга, ожидайте...</div>';
		document.body.appendChild(wndinfo);
		
		if (azs_id
			&& (elems = document.querySelectorAll('div.search-fuel-info-view__rate._has-value'))
			&& elems.length) {
			let ya_date = document.querySelector('.search-fuel-info-view__info span').innerHTML;
			if (ya_date) {
				ya_date = ya_date.split(' ');
				if (ya_date[1] && ya_date[2] && ya_date[3])
					ya_date = ya_date[1]+' '+ya_date[2]+' '+ya_date[3];
				else
					ya_date = '';
			}
			else
				ya_date = '';
			for (let k in elems) {
				if ((k = parseInt(k)) >= 0) {
					out[k] = {fuel:elems[k].querySelector('div.search-fuel-info-view__name').innerHTML,
								price:elems[k].querySelector('div.search-fuel-info-view__value').innerHTML,
								yandex_date:ya_date};
				}
			}
			this.saveAzsPrices({id:azs_id,prices:JSON.stringify(out)});
		}
		else {
			this.getNextAzs();
		}
	}
	async sendData(data) {
		await YMSurfer.sleep(2);
		chrome.runtime.sendMessage({method: "openAzsTab",data});
	}
	saveAzsPrices(data) {
		let dta = new FormData();
		dta.append('id', data.id);
		dta.append('prices', data.prices);
		this.send_data = true;
		this.xhr.open('POST', YMSurfer.SERVICE_ADDR+'azs_save_prices.php');
		this.xhr.send(dta);
	}
	getNextAzs() {
		let dta = new FormData();
		this.send_data = true;
		this.xhr.open('POST', YMSurfer.SERVICE_ADDR+'azs_get.php');
		this.xhr.send(dta);
	}
	static sleep(s) {
		return new Promise(resolve => setTimeout(resolve, s*1000));
	}
}

let ysurf = new YMSurfer();

chrome.runtime.onMessage.addListener((msg, sender, resp) => {
	if (msg.method) {
		if (typeof resp == 'undefined') {
			try {
				ysurf[msg.method](typeof msg.data != 'undefined'?msg.data:null);
			}
			catch (err) {
				alert(err.message);
			}
		}
		else
			resp(ysurf[msg.method](typeof msg.data != 'undefined'?msg.data:null));
	}
});
