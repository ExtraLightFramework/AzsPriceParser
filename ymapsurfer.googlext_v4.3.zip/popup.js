window.onload = function() {

	swButtons();
  	document.getElementById('start-parse').onclick = function() {
		chrome.runtime.sendMessage({method: "setStatus", data:'active'});
		swButtons();
	};
  	document.getElementById('stop-parse').onclick = function() {
		chrome.runtime.sendMessage({method: "setStatus", data: 'inactive'});
		swButtons();
	};
}
function swButtons() {
	let startb = document.getElementById('start-parse');
	let stopb = document.getElementById('stop-parse');
	chrome.runtime.sendMessage({method: "getStatus"}, (resp) => {
		if (resp == 'active') {
			startb.style.display = 'none';
			stopb.style.display = 'block';
		}
		else {
			startb.style.display = 'block';
			stopb.style.display = 'none';
		}
	});
}
